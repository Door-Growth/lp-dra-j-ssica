"use strict";

document.documentElement.classList.add("js");

const whatsappLink = "https://api.whatsapp.com/send?phone=556699038231&text=Ol%C3%A1%21%20Gostaria%20de%20ter%20mais%20informa%C3%A7%C3%B5es%20sobre%20a%20consulta%20com%20a%20Dra.%20J%C3%A9ssica%20Ferreira%2C%20por%20favor.";

// DEPOIMENTOS ILUSTRATIVOS: substituir por avaliações reais e autorizadas antes da publicação.
const testimonials = [
  {
    name: "Juliana A.",
    initials: "JA",
    gender: "female",
    rating: 5,
    text: "Cheguei por indicação de uma amiga e já na primeira consulta entendi por que ela falava tão bem. A Dra. Jéssica é atenciosa, prática e não tenta encaixar todo mundo no mesmo tratamento. Saí com uma estratégia que fazia sentido para minha realidade e sem aquelas promessas milagrosas. Experiência maravilhosa! 🌿",
    status: "placeholder"
  },
  {
    name: "André P.",
    initials: "AP",
    gender: "male",
    rating: 5,
    text: "Usei a medicação sem acompanhamento porque vi muita gente falando sobre ela. Tive desconfortos gastrointestinais e não sabia se deveria parar, diminuir ou continuar. A Dra. Jéssica me orientou com muita responsabilidade e explicou que cada resposta do organismo precisa ser avaliada. Me senti acolhido e, principalmente, bem informado. 🙌",
    status: "placeholder"
  },
  {
    name: "Camila R.",
    initials: "CR",
    gender: "female",
    rating: 5,
    text: "Eu perdi peso rápido, mas junto perdi bastante massa muscular. Percebi que estava mais fraca e sem disposição para coisas simples do dia a dia. A Dra. Jéssica mudou completamente minha visão sobre emagrecimento e passou a olhar também para força, alimentação e composição corporal. Foi um cuidado que eu não tinha antes. 💪✨",
    status: "placeholder"
  },
  {
    name: "Rafael C.",
    initials: "RC",
    gender: "male",
    rating: 5,
    text: "Eu imaginava que a consulta seria apenas para receber uma prescrição, mas foi muito mais completa. Falamos sobre sono, alimentação, exames, rotina de trabalho e até sobre minha dificuldade de manter hábitos. Gostei porque o tratamento foi pensado para mim e não baseado apenas no número da balança. 👏",
    status: "placeholder"
  },
  {
    name: "Patrícia M.",
    initials: "PM",
    gender: "female",
    rating: 5,
    text: "Meu cabelo começou a cair muito depois que iniciei o processo e eu fiquei desesperada. Achei que era algo normal e que precisava apenas esperar passar. A Dra. Jéssica investigou minha alimentação, exames, vitaminas e rotina. Gostei porque ela não minimizou o que eu estava sentindo e explicou tudo de forma muito clara. ❤️",
    status: "placeholder"
  },
  {
    name: "Renata L.",
    initials: "RL",
    gender: "female",
    rating: 5,
    text: "O meu maior medo era emagrecer e recuperar tudo de novo, porque já passei por isso várias vezes. Na consulta, conversamos muito sobre o que aconteceria depois da perda de peso, e não apenas sobre o início. Pela primeira vez senti que existia um plano de verdade para manutenção. Isso fez toda a diferença para mim. 😊",
    status: "placeholder"
  },
  {
    name: "Lucas F.",
    initials: "LF",
    gender: "male",
    rating: 5,
    text: "Fui até a Dra. Jéssica porque estava perdendo peso, mas também muita energia para treinar e trabalhar. Ela analisou meu caso com cuidado e mostrou que o objetivo não poderia ser apenas emagrecer rápido. O acompanhamento tem sido muito mais equilibrado e hoje consigo enxergar o processo de uma forma mais saudável. 🚀",
    status: "placeholder"
  },
  {
    name: "Mariana S.",
    initials: "MS",
    gender: "female",
    rating: 5,
    text: "Comecei a usar a medicação por conta própria e, no início, achei que estava tudo bem. Depois vieram enjoos fortes, fraqueza e muita dificuldade para me alimentar. Na consulta, a Dra. Jéssica ouviu tudo com calma e me explicou que não era só ‘aguentar os efeitos’. Hoje me sinto muito mais segura com o acompanhamento. 🙏",
    status: "placeholder"
  }
];

window.dataLayer = window.dataLayer || [];

function pushEvent(event, details = {}) {
  if (Array.isArray(window.dataLayer)) window.dataLayer.push({ event, ...details });
}

function safelyRun(name, callback) {
  try { callback(); } catch (error) { document.documentElement.dataset[`${name}Fallback`] = "active"; }
}

document.addEventListener("DOMContentLoaded", () => {
  const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches || false;
  safelyRun("base", () => initBase(reducedMotion));
  safelyRun("menu", initMenu);
  safelyRun("scroll", initScrollFeatures);
  safelyRun("reveal", initReveal);
  safelyRun("navigation", initNavigation);
  safelyRun("faq", () => initFaq(reducedMotion));
  safelyRun("carousel", () => initCarousels(reducedMotion));
  safelyRun("testimonials", () => initTestimonials(reducedMotion));
  safelyRun("processCallouts", initProcessCallouts);
});

function initBase(reducedMotion) {
  const year = document.querySelector("#currentYear");
  if (year) year.textContent = new Date().getFullYear();

  document.querySelectorAll("[data-whatsapp]").forEach((link) => {
    link.href = whatsappLink;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });

  document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach((link) => {
    link.addEventListener("click", (event) => {
      const target = document.querySelector(link.getAttribute("href"));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
    });
  });
}

function initProcessCallouts() {
  const panel = document.querySelector(".integrated-process-panel");
  const callouts = panel ? [...panel.querySelectorAll(".process-callout")] : [];
  if (!panel || !callouts.length) return;

  const mobileQuery = window.matchMedia("(max-width: 767px)");

  const closeAll = (except = null) => {
    callouts.forEach((callout) => {
      if (callout === except) return;
      callout.classList.remove("is-expanded");
      callout.setAttribute("aria-expanded", "false");
    });
  };

  const toggle = (callout) => {
    if (!mobileQuery.matches) return;
    const willOpen = !callout.classList.contains("is-expanded");
    closeAll(willOpen ? callout : null);
    callout.classList.toggle("is-expanded", willOpen);
    callout.setAttribute("aria-expanded", String(willOpen));
  };

  const applyMode = () => {
    closeAll();
    callouts.forEach((callout) => {
      if (mobileQuery.matches) {
        callout.setAttribute("role", "button");
        callout.setAttribute("tabindex", "0");
        callout.setAttribute("aria-expanded", "false");
      } else {
        callout.removeAttribute("role");
        callout.removeAttribute("tabindex");
        callout.removeAttribute("aria-expanded");
      }
    });
  };

  callouts.forEach((callout) => {
    callout.addEventListener("click", () => toggle(callout));
    callout.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      toggle(callout);
    });
  });

  mobileQuery.addEventListener?.("change", applyMode);
  applyMode();
}

function initMenu() {
  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector("#mobileMenu");
  const backdrop = document.querySelector(".menu-backdrop");
  if (!toggle || !menu || !backdrop) return;
  let previousFocus = null;
  const focusables = () => [...menu.querySelectorAll("a, button")];

  const close = () => {
    document.body.classList.remove("menu-open");
    menu.classList.remove("is-open");
    backdrop.classList.remove("is-open");
    menu.setAttribute("aria-hidden", "true");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Abrir menu");
    previousFocus?.focus?.();
  };
  const open = () => {
    previousFocus = document.activeElement;
    document.body.classList.add("menu-open");
    menu.classList.add("is-open");
    backdrop.classList.add("is-open");
    menu.setAttribute("aria-hidden", "false");
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Fechar menu");
    focusables()[0]?.focus();
  };

  toggle.addEventListener("click", () => menu.classList.contains("is-open") ? close() : open());
  document.querySelectorAll("[data-menu-close]").forEach((item) => item.addEventListener("click", close));
  menu.querySelectorAll("a").forEach((item) => item.addEventListener("click", close));
  document.addEventListener("keydown", (event) => {
    if (!menu.classList.contains("is-open")) return;
    if (event.key === "Escape") return close();
    if (event.key !== "Tab") return;
    const items = focusables();
    const first = items[0];
    const last = items.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
}

function initScrollFeatures() {
  const header = document.querySelector("#siteHeader");
  const progress = document.querySelector("#scrollProgress");
  const floating = document.querySelector(".whatsapp-floating");
  const hero = document.querySelector(".hero");
  const exclusionZones = [...document.querySelectorAll(".faq, .final-cta, .site-footer")];
  const mobileProcessZone = document.querySelector(".integrated-process");
  let ticking = false;

  const update = () => {
    const top = window.scrollY || 0;
    const max = Math.max(document.documentElement.scrollHeight - window.innerHeight, 1);
    const percent = Math.min(100, Math.max(0, top / max * 100));
    if (progress) progress.style.width = `${percent}%`;
    header?.classList.toggle("header-scrolled", top > 18);
    if (floating && hero) {
      const visible = top > Math.min(window.innerHeight * .22, hero.offsetHeight * .22);
      const mobileZones = window.innerWidth <= 767 && mobileProcessZone ? [mobileProcessZone] : [];
      const overlapsZone = [...exclusionZones, ...mobileZones].some((zone) => {
        const rect = zone.getBoundingClientRect();
        return rect.top < window.innerHeight - 20 && rect.bottom > window.innerHeight - 20;
      });
      floating.classList.toggle("is-visible", visible);
      floating.classList.toggle("is-hidden-zone", overlapsZone);
    }
    ticking = false;
  };

  window.addEventListener("scroll", () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(update);
  }, { passive: true });
  window.addEventListener("resize", update, { passive: true });
  update();
}

function initReveal() {
  const items = [...document.querySelectorAll(".reveal")];
  if (!("IntersectionObserver" in window)) return items.forEach((item) => item.classList.add("active"));
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("active");
      observer.unobserve(entry.target);
    });
  }, { threshold: .05, rootMargin: "0px 0px -16px" });
  items.forEach((item) => observer.observe(item));
  window.setTimeout(() => items.forEach((item) => item.classList.add("active")), 1600);
}

function initNavigation() {
  if (!("IntersectionObserver" in window)) return;
  const links = [...document.querySelectorAll(".desktop-nav a")];
  const sections = [...document.querySelectorAll("main section[id]")];
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      links.forEach((link) => link.classList.toggle("active", link.hash === `#${entry.target.id}`));
    });
  }, { rootMargin: "-35% 0px -55%" });
  sections.forEach((section) => observer.observe(section));
}

function initFaq(reducedMotion) {
  const items = [...document.querySelectorAll(".faq-item")];
  items.forEach((item) => {
    const button = item.querySelector("button[aria-controls]");
    const panel = button && document.getElementById(button.getAttribute("aria-controls"));
    if (!button || !panel) return;
    button.addEventListener("click", () => {
      const opening = button.getAttribute("aria-expanded") !== "true";
      items.forEach((other) => {
        if (other === item) return;
        const otherButton = other.querySelector("button[aria-controls]");
        const otherPanel = otherButton && document.getElementById(otherButton.getAttribute("aria-controls"));
        if (!otherButton || !otherPanel) return;
        otherButton.setAttribute("aria-expanded", "false");
        other.querySelector("i").textContent = "+";
        other.classList.remove("is-open");
        otherPanel.hidden = true;
      });
      button.setAttribute("aria-expanded", String(opening));
      button.querySelector("i").textContent = opening ? "−" : "+";
      item.classList.toggle("is-open", opening);
      if (reducedMotion || typeof panel.animate !== "function") {
        panel.hidden = !opening;
      } else if (opening) {
        panel.hidden = false;
        panel.animate([{ height: "0", opacity: 0 }, { height: `${panel.scrollHeight}px`, opacity: 1 }], { duration: 280, easing: "ease" });
      } else {
        const animation = panel.animate([{ height: `${panel.scrollHeight}px`, opacity: 1 }, { height: "0", opacity: 0 }], { duration: 210, easing: "ease" });
        animation.onfinish = () => { panel.hidden = true; };
      }
      if (opening) pushEvent("faq_open", { faq_question: button.querySelector("span").textContent.trim() });
    });
  });
}

function initCarousels(reducedMotion) {
  document.querySelectorAll("[data-carousel]").forEach((carousel) => {
    const track = carousel.querySelector("[data-carousel-track]");
    const previous = carousel.querySelector("[data-carousel-prev]");
    const next = carousel.querySelector("[data-carousel-next]");
    if (!track || !previous || !next) return;
    const cards = [...track.children];
    const cardLeft = (index) => cards[index].offsetLeft - cards[0].offsetLeft;
    const activeIndex = () => cards.reduce((closest, card, index) => {
      const distance = Math.abs(track.scrollLeft - cardLeft(index));
      return distance < closest.distance ? { index, distance } : closest;
    }, { index: 0, distance: Infinity }).index;
    const update = () => {
      previous.disabled = track.scrollLeft <= 4;
      next.disabled = track.scrollLeft >= track.scrollWidth - track.clientWidth - 4;
      const index = activeIndex();
      cards.forEach((card, cardIndex) => card.classList.toggle("is-active", cardIndex === index));
    };
    const move = (direction) => {
      const index = Math.max(0, Math.min(cards.length - 1, activeIndex() + direction));
      track.scrollTo({ left: cardLeft(index), behavior: reducedMotion ? "auto" : "smooth" });
    };
    previous.addEventListener("click", () => move(-1));
    next.addEventListener("click", () => move(1));
    let scrollFrame = 0;
    track.addEventListener("scroll", () => {
      cancelAnimationFrame(scrollFrame);
      scrollFrame = requestAnimationFrame(update);
    }, { passive: true });
    window.addEventListener("resize", update, { passive: true });
    track.addEventListener("keydown", (event) => {
      if (event.key === "ArrowLeft") { event.preventDefault(); move(-1); }
      if (event.key === "ArrowRight") { event.preventDefault(); move(1); }
      if (event.key === "Home") { event.preventDefault(); track.scrollTo({ left: 0, behavior: reducedMotion ? "auto" : "smooth" }); }
      if (event.key === "End") { event.preventDefault(); track.scrollTo({ left: cardLeft(cards.length - 1), behavior: reducedMotion ? "auto" : "smooth" }); }
    });

    let dragging = false;
    let startX = 0;
    let startScroll = 0;
    track.addEventListener("pointerdown", (event) => {
      if (event.pointerType !== "mouse" || event.button !== 0) return;
      dragging = true;
      startX = event.clientX;
      startScroll = track.scrollLeft;
      track.classList.add("is-dragging");
      track.setPointerCapture?.(event.pointerId);
    });
    track.addEventListener("pointermove", (event) => {
      if (!dragging) return;
      event.preventDefault();
      track.scrollLeft = startScroll - (event.clientX - startX);
    });
    const stopDragging = (event) => {
      if (!dragging) return;
      dragging = false;
      track.classList.remove("is-dragging");
      track.releasePointerCapture?.(event.pointerId);
      track.scrollTo({ left: cardLeft(activeIndex()), behavior: reducedMotion ? "auto" : "smooth" });
    };
    track.addEventListener("pointerup", stopDragging);
    track.addEventListener("pointercancel", stopDragging);
    update();
    window.setTimeout(update, 200);
  });
}

function initTestimonials(reducedMotion) {
  const section = document.querySelector(".testimonials");
  const carousel = section?.querySelector("[data-testimonials-carousel]");
  const track = carousel?.querySelector("[data-testimonials-track]");
  const previous = carousel?.querySelector("[data-testimonial-prev]");
  const next = carousel?.querySelector("[data-testimonial-next]");
  const indicators = carousel?.querySelector("[data-testimonial-indicators]");
  const cards = track ? [...track.querySelectorAll(".testimonial-card")] : [];
  if (!section || !carousel || !track || !previous || !next || !indicators || !cards.length) return;

  const cardLeft = (index) => cards[index].offsetLeft - cards[0].offsetLeft;
  const visibleCardCount = () => {
    const gap = Number.parseFloat(getComputedStyle(track).columnGap) || 0;
    const step = cards[0].offsetWidth + gap;
    return Math.max(1, Math.min(cards.length, Math.round(track.clientWidth / step)));
  };
  const lastStartIndex = () => Math.max(0, cards.length - visibleCardCount());
  const activeIndex = () => cards.reduce((closest, card, index) => {
    const distance = Math.abs(track.scrollLeft - cardLeft(index));
    return distance < closest.distance ? { index, distance } : closest;
  }, { index: 0, distance: Infinity }).index;

  let dots = [];
  const rebuildIndicators = () => {
    const count = lastStartIndex() + 1;
    if (dots.length === count) return;
    indicators.replaceChildren();
    dots = Array.from({ length: count }, (_, index) => {
      const button = document.createElement("button");
      const name = testimonials[index]?.name || cards[index].querySelector("h3")?.textContent || `depoimento ${index + 1}`;
      button.type = "button";
      button.setAttribute("aria-label", `Ir para o depoimento de ${name}`);
      button.addEventListener("click", () => scrollToCard(index));
      indicators.appendChild(button);
      return button;
    });
  };

  const update = () => {
    const index = Math.min(activeIndex(), lastStartIndex());
    dots.forEach((dot, dotIndex) => dot.classList.toggle("is-active", dotIndex === index));
    previous.disabled = track.scrollLeft <= 4;
    next.disabled = track.scrollLeft >= track.scrollWidth - track.clientWidth - 4;
  };

  function scrollToCard(index) {
    const safeIndex = Math.max(0, Math.min(lastStartIndex(), index));
    track.scrollTo({ left: cardLeft(safeIndex), behavior: reducedMotion ? "auto" : "smooth" });
  }

  previous.addEventListener("click", () => scrollToCard(activeIndex() - 1));
  next.addEventListener("click", () => scrollToCard(activeIndex() + 1));
  track.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") { event.preventDefault(); scrollToCard(activeIndex() - 1); }
    if (event.key === "ArrowRight") { event.preventDefault(); scrollToCard(activeIndex() + 1); }
    if (event.key === "Home") { event.preventDefault(); scrollToCard(0); }
    if (event.key === "End") { event.preventDefault(); scrollToCard(cards.length - 1); }
  });

  let scrollFrame = 0;
  track.addEventListener("scroll", () => {
    cancelAnimationFrame(scrollFrame);
    scrollFrame = requestAnimationFrame(update);
  }, { passive: true });

  let dragging = false;
  let startX = 0;
  let startScroll = 0;
  track.addEventListener("pointerdown", (event) => {
    if (event.pointerType !== "mouse" || event.button !== 0 || event.target.closest("button")) return;
    dragging = true;
    startX = event.clientX;
    startScroll = track.scrollLeft;
    track.classList.add("is-dragging");
    track.setPointerCapture?.(event.pointerId);
  });
  track.addEventListener("pointermove", (event) => {
    if (!dragging) return;
    event.preventDefault();
    track.scrollLeft = startScroll - (event.clientX - startX);
  });
  const stopDragging = (event) => {
    if (!dragging) return;
    dragging = false;
    track.classList.remove("is-dragging");
    track.releasePointerCapture?.(event.pointerId);
    scrollToCard(activeIndex());
  };
  track.addEventListener("pointerup", stopDragging);
  track.addEventListener("pointercancel", stopDragging);

  cards.forEach((card) => {
    const button = card.querySelector(".testimonial-toggle");
    const text = button && document.getElementById(button.getAttribute("aria-controls"));
    if (!button || !text) return;
    button.addEventListener("click", () => {
      const expanded = button.getAttribute("aria-expanded") !== "true";
      button.setAttribute("aria-expanded", String(expanded));
      button.textContent = expanded ? "Mostrar menos" : "Ler mais";
      card.classList.toggle("is-expanded", expanded);
    });
  });

  const updateTextControls = () => {
    cards.forEach((card) => {
      if (card.classList.contains("is-expanded")) return;
      const button = card.querySelector(".testimonial-toggle");
      const text = button && document.getElementById(button.getAttribute("aria-controls"));
      if (!button || !text) return;
      button.hidden = text.scrollHeight <= text.clientHeight + 2;
    });
  };

  section.classList.add("is-enhanced");
  window.addEventListener("resize", () => { rebuildIndicators(); update(); updateTextControls(); }, { passive: true });
  requestAnimationFrame(() => { rebuildIndicators(); update(); updateTextControls(); });
}
