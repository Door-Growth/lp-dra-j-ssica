"use strict";

(() => {
  const LP_CONFIG = Object.freeze({
    client_name: "Dra. Jéssica",
    lp_name: "LP Dra. Jéssica",
    lp_slug: "dra_jessica",
    product_name: "Acompanhamento médico para emagrecimento",
    product_slug: "emagrecimento_medico",
    ga4_id: "G-JVBEXFMYC4",
    meta_pixel_id: "1073203531921409",
    ga4_main_event: "generate_lead",
    meta_main_event: "whatsapp_lp",
    business_city: "Rondonópolis",
    business_state: "MT",
    campaign_region: ""
  });

  const PREFIX = "dra_jessica_";
  const LEAD_LOCK_KEY = `${PREFIX}generate_lead_last_sent`;
  const LEAD_LOCK_MS = 24 * 60 * 60 * 1000;
  const CAMPAIGN_KEYS = [
    "utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term",
    "utm_id", "gclid", "fbclid", "msclkid", "ttclid", "wbraid", "gbraid"
  ];
  const SCROLL_THRESHOLDS = [25, 50, 75, 90];
  const qs = new URLSearchParams(window.location.search);
  const pageStartedAt = Date.now();
  const scrollEventsSent = new Set();
  let maxScrollPercent = 0;
  let lpViewSent = false;

  const debugLog = (...args) => {
    if (qs.get("debug_mode") === "true") {
      console.log("[DraJessicaTracking]", ...args);
    }
  };

  const storageGet = (storage, key) => {
    try {
      return storage.getItem(key) || "";
    } catch {
      return "";
    }
  };

  const storageSet = (storage, key, value) => {
    if (!value) return;
    try {
      storage.setItem(key, value);
    } catch {
      // Tracking must never interrupt the landing page experience.
    }
  };

  const createAnonymousValue = () =>
    `${PREFIX}${Date.now()}_${Math.random().toString(36).slice(2)}`;

  const ensureStoredValue = (storage, key) => {
    const current = storageGet(storage, key);
    if (current) return current;
    const created = createAnonymousValue();
    storageSet(storage, key, created);
    return storageGet(storage, key) || created;
  };

  const compact = (object) =>
    Object.fromEntries(
      Object.entries(object).filter(([, value]) =>
        value !== undefined && value !== null && value !== ""
      )
    );

  const getCookie = (name) => {
    const encodedName = `${encodeURIComponent(name)}=`;
    const part = document.cookie
      .split(";")
      .map((item) => item.trim())
      .find((item) => item.startsWith(encodedName));
    return part ? decodeURIComponent(part.slice(encodedName.length)) : "";
  };

  const getGaClientId = () => {
    const value = getCookie("_ga");
    if (!value) return "";
    const match = value.match(/^GA\d+\.\d+\.(.+)$/);
    return match ? match[1] : "";
  };

  const getGaSessionId = () => {
    const streamSuffix = LP_CONFIG.ga4_id.replace(/^G-/, "");
    const value = getCookie(`_ga_${streamSuffix}`);
    if (!value) return "";
    const legacyMatch = value.match(/^GS\d+\.\d+\.(\d+)/);
    if (legacyMatch) return legacyMatch[1];
    const currentMatch = value.match(/(?:^|\.)s(\d+)(?:\.|$)/);
    return currentMatch ? currentMatch[1] : "";
  };

  const detectDeviceType = () => {
    const ua = navigator.userAgent;
    if (/iPad|Tablet|PlayBook|Silk/i.test(ua) || (/Android/i.test(ua) && !/Mobile/i.test(ua))) {
      return "tablet";
    }
    if (/Mobi|iPhone|iPod|Android/i.test(ua)) return "mobile";
    return "desktop";
  };

  const detectDeviceOs = () => {
    const ua = navigator.userAgent;
    if (/iPhone|iPad|iPod/i.test(ua)) return "ios";
    if (/Android/i.test(ua)) return "android";
    if (/Windows/i.test(ua)) return "windows";
    if (/Mac OS/i.test(ua)) return "macos";
    if (/Linux/i.test(ua)) return "linux";
    return "unknown";
  };

  const detectBrowser = () => {
    const ua = navigator.userAgent;
    if (/Edg\//i.test(ua)) return "edge";
    if (/OPR\/|Opera/i.test(ua)) return "opera";
    if (/Firefox\//i.test(ua)) return "firefox";
    if (/Chrome\//i.test(ua) && !/Edg\//i.test(ua)) return "chrome";
    if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) return "safari";
    return "unknown";
  };

  const calculateScroll = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    if (max <= 0) return 100;
    return Math.max(0, Math.min(100, Math.round((window.scrollY / max) * 100)));
  };

  const initializeSession = () => {
    ensureStoredValue(sessionStorage, `${PREFIX}session_id`);
    ensureStoredValue(localStorage, `${PREFIX}anonymous_id`);

    if (!storageGet(sessionStorage, `${PREFIX}landing_page_url`)) {
      storageSet(sessionStorage, `${PREFIX}landing_page_url`, window.location.href);
    }
    if (!storageGet(sessionStorage, `${PREFIX}first_page_path`)) {
      storageSet(sessionStorage, `${PREFIX}first_page_path`, window.location.pathname);
    }

    CAMPAIGN_KEYS.forEach((key) => {
      const valueFromUrl = qs.get(key);
      if (valueFromUrl) storageSet(sessionStorage, `${PREFIX}${key}`, valueFromUrl);
    });
  };

  const getCampaignData = () =>
    Object.fromEntries(
      CAMPAIGN_KEYS.map((key) => [
        key,
        qs.get(key) || storageGet(sessionStorage, `${PREFIX}${key}`)
      ])
    );

  const createEventId = (eventName) =>
    `${LP_CONFIG.lp_slug}_${eventName}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

  const getCommonEventData = (eventId) => {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    const payload = compact({
      client_name: LP_CONFIG.client_name,
      lp_name: LP_CONFIG.lp_name,
      lp_slug: LP_CONFIG.lp_slug,
      product_name: LP_CONFIG.product_name,
      product_slug: LP_CONFIG.product_slug,
      page_url: window.location.href,
      page_path: window.location.pathname,
      page_title: document.title,
      referrer: document.referrer || "",
      landing_page_url: storageGet(sessionStorage, `${PREFIX}landing_page_url`),
      first_page_path: storageGet(sessionStorage, `${PREFIX}first_page_path`),
      timestamp: new Date().toISOString(),
      event_id: eventId,
      session_id: storageGet(sessionStorage, `${PREFIX}session_id`),
      anonymous_id: storageGet(localStorage, `${PREFIX}anonymous_id`),
      ...getCampaignData(),
      _fbp: getCookie("_fbp"),
      _fbc: getCookie("_fbc"),
      ga_client_id: getGaClientId(),
      ga_session_id: getGaSessionId(),
      user_agent: navigator.userAgent,
      browser_language: navigator.language,
      browser_languages: navigator.languages ? navigator.languages.join(",") : "",
      screen_width: window.screen?.width,
      screen_height: window.screen?.height,
      viewport_width: window.innerWidth,
      viewport_height: window.innerHeight,
      pixel_ratio: window.devicePixelRatio,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      timezone_offset: new Date().getTimezoneOffset(),
      device_type: detectDeviceType(),
      device_os: detectDeviceOs(),
      browser: detectBrowser(),
      connection_type: connection?.type,
      effective_connection_type: connection?.effectiveType,
      device_memory: navigator.deviceMemory,
      hardware_concurrency: navigator.hardwareConcurrency,
      business_city: LP_CONFIG.business_city,
      business_state: LP_CONFIG.business_state,
      campaign_region: LP_CONFIG.campaign_region,
      max_scroll_percent: Math.max(maxScrollPercent, calculateScroll()),
      time_on_page_seconds: Math.max(0, Math.round((Date.now() - pageStartedAt) / 1000)),
      page_visibility: document.visibilityState
    });
    debugLog("Common data", payload);
    return payload;
  };

  const trackGA4 = (eventName, payload, callback) => {
    if (typeof window.gtag !== "function") {
      debugLog(`GA4 unavailable for ${eventName}`);
      if (typeof callback === "function") setTimeout(callback, 0);
      return;
    }
    const parameters = {
      ...payload,
      transport_type: "beacon",
      event_timeout: 1500
    };
    if (typeof callback === "function") parameters.event_callback = callback;
    window.gtag("event", eventName, parameters);
  };

  const trackMeta = (eventName, payload, options = {}) => {
    if (typeof window.fbq !== "function") {
      debugLog(`Meta unavailable for ${eventName}`);
      return;
    }
    const metaOptions = { eventID: payload.event_id };
    if (options.standard) {
      window.fbq("track", eventName, payload, metaOptions);
    } else {
      window.fbq("trackCustom", eventName, payload, metaOptions);
    }
  };

  const cleanText = (element) => {
    if (!element) return "";
    const text = element.innerText || element.getAttribute("aria-label") || "";
    return text.replace(/\s+/g, " ").trim().slice(0, 160);
  };

  const inferButtonLocation = (link) => {
    const declared = (link?.dataset?.location || "").toLowerCase();
    if (link?.closest("header") || declared === "header" || declared === "mobile_menu") return "header";
    if (link?.closest(".hero, #inicio") || declared === "hero") return "hero";
    if (link?.matches(".whatsapp-floating") || declared.includes("floating") || declared === "sticky") return "sticky";
    if (link?.closest(".final-cta") || declared.includes("final")) return "final";
    if (link?.closest("footer") || declared === "footer") return "footer";
    if (link?.closest(".faq, #duvidas") || declared === "faq") return "faq";
    return "meio";
  };

  const wasLeadSentRecently = () => {
    const sentAt = Number(storageGet(localStorage, LEAD_LOCK_KEY));
    return Number.isFinite(sentAt) && sentAt > 0 && Date.now() - sentAt < LEAD_LOCK_MS;
  };

  const setLeadLock = () => storageSet(localStorage, LEAD_LOCK_KEY, String(Date.now()));

  const sendRepeatClick = (link, destinationUrl) => {
    const eventName = "whatsapp_repeat_click_dra_jessica";
    const eventId = createEventId(eventName);
    const payload = compact({
      ...getCommonEventData(eventId),
      conversion_type: "whatsapp_repeat_click",
      lead_source: "landing_page",
      lead_channel: "whatsapp",
      event_category: "engagement",
      event_label: eventName,
      button_text: cleanText(link),
      button_location: inferButtonLocation(link),
      destination_url: destinationUrl,
      lead_already_sent: true
    });
    trackGA4(eventName, payload);
    trackMeta(eventName, payload);
  };

  const handleWhatsAppLead = (event, link) => {
    if (event && event.button && event.button !== 0) return;
    const destinationUrl = link.href;
    if (!destinationUrl || destinationUrl === "#") return;
    if (event) event.preventDefault();

    let redirected = false;
    const redirect = () => {
      if (redirected) return;
      redirected = true;
      debugLog("Redirect URL", destinationUrl);
      window.location.href = destinationUrl;
    };

    debugLog("Lead click detected", {
      button_text: cleanText(link),
      button_location: inferButtonLocation(link),
      destination_url: destinationUrl
    });

    if (wasLeadSentRecently()) {
      debugLog("Lead already sent in last 24h, redirecting only");
      sendRepeatClick(link, destinationUrl);
      redirect();
      return;
    }

    setLeadLock();
    const eventId = createEventId(LP_CONFIG.ga4_main_event);
    const payload = compact({
      ...getCommonEventData(eventId),
      conversion_type: "whatsapp",
      lead_source: "landing_page",
      lead_channel: "whatsapp",
      event_category: "conversion",
      event_label: "whatsapp_dra_jessica",
      button_text: cleanText(link),
      button_location: inferButtonLocation(link),
      destination_url: destinationUrl
    });

    trackGA4(LP_CONFIG.ga4_main_event, payload, redirect);
    debugLog("GA4 generate_lead sent", payload);
    trackMeta(LP_CONFIG.meta_main_event, payload);
    debugLog("Meta whatsapp_lp sent", payload);
    setTimeout(redirect, 1600);
  };

  const mapWhatsAppLinks = () => {
    const links = [
      ...document.querySelectorAll(
        '[data-whatsapp], a[href*="api.whatsapp.com/send"], a[href*="wa.me/"]'
      )
    ];
    links.forEach((link) => {
      if (link.dataset.draJessicaTrackingBound === "true") return;
      link.dataset.draJessicaTrackingBound = "true";
      link.addEventListener("click", (event) => handleWhatsAppLead(event, link));
    });
    debugLog(`WhatsApp links mapped: ${links.length}`);
    return links.length;
  };

  const mapForms = () => {
    document.querySelectorAll("form").forEach((form) => {
      if (form.dataset.draJessicaTrackingBound === "true") return;
      form.dataset.draJessicaTrackingBound = "true";
      form.addEventListener("submit", () => {
        if (wasLeadSentRecently()) return;
        setLeadLock();
        const eventId = createEventId(LP_CONFIG.ga4_main_event);
        const payload = compact({
          ...getCommonEventData(eventId),
          conversion_type: "form_submit",
          lead_source: "landing_page",
          lead_channel: "form",
          event_category: "conversion",
          event_label: "form_dra_jessica",
          form_id: form.id || "",
          form_name: form.getAttribute("name") || "",
          form_location: inferButtonLocation(form)
        });
        trackGA4(LP_CONFIG.ga4_main_event, payload);
        trackMeta(LP_CONFIG.meta_main_event, payload);
      });
    });
  };

  const sendLpView = () => {
    if (lpViewSent) return;
    lpViewSent = true;
    const eventName = "lp_view_dra_jessica";
    const eventId = createEventId(eventName);
    const payload = getCommonEventData(eventId);
    trackGA4(eventName, payload);
    trackMeta(eventName, payload);
    debugLog("LP view sent", payload);
  };

  const handleScroll = () => {
    const current = calculateScroll();
    maxScrollPercent = Math.max(maxScrollPercent, current);
    SCROLL_THRESHOLDS.forEach((threshold) => {
      if (current < threshold || scrollEventsSent.has(threshold)) return;
      scrollEventsSent.add(threshold);
      const eventName = `scroll_${threshold}_dra_jessica`;
      const eventId = createEventId(eventName);
      const payload = compact({
        ...getCommonEventData(eventId),
        scroll_percent: threshold,
        max_scroll_percent: Math.max(current, threshold)
      });
      trackGA4(eventName, payload);
      trackMeta(eventName, payload);
      debugLog(`Scroll event sent: ${threshold}`, payload);
    });
  };

  const initializeTracking = () => {
    initializeSession();
    debugLog("Tracking loaded", LP_CONFIG);
    sendLpView();
    mapWhatsAppLinks();
    mapForms();
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
  };

  window.draJessicaTrackLead = (linkOrSelector) => {
    const link = typeof linkOrSelector === "string"
      ? document.querySelector(linkOrSelector)
      : linkOrSelector;
    if (!link) return false;
    handleWhatsAppLead(null, link);
    return true;
  };

  window.draJessicaTracking = Object.freeze({
    config: LP_CONFIG,
    createEventId,
    getCommonEventData,
    inferButtonLocation,
    cleanText,
    trackGA4,
    trackMeta
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeTracking, { once: true });
  } else {
    initializeTracking();
  }
})();
